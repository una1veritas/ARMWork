ST7032i I2C LCD
library working with armcmx
