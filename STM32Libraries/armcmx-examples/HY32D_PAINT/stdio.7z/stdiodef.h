#ifndef __STDIODEFC_H
#define __STDIODEF_H

#ifdef __cplusplus
 extern "C" {
#endif

#include "stm32f4xx.h"

#include "armcmx.h"

#ifdef __cplusplus
}
#endif

#endif
