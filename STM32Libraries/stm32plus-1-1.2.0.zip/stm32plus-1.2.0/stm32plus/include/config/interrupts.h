/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */


#pragma once

/// DMA interrupts

#define USE_DMA1_1_INTERRUPT
#define USE_DMA1_2_INTERRUPT
#define USE_DMA1_3_INTERRUPT
#define USE_DMA1_4_INTERRUPT
#define USE_DMA1_5_INTERRUPT
#define USE_DMA1_6_INTERRUPT
#define USE_DMA1_7_INTERRUPT
#define USE_DMA2_1_INTERRUPT
#define USE_DMA2_2_INTERRUPT
#define USE_DMA2_3_INTERRUPT
#define USE_DMA2_4_5_INTERRUPT

/// USART interrupts

#define USE_USART1_INTERRUPT
#define USE_USART2_INTERRUPT
#define USE_USART3_INTERRUPT
#define USE_UART4_INTERRUPT
#define USE_UART5_INTERRUPT

/// RTC interrupt

#define USE_RTC_INTERRUPT

/// SPI interrupts

#define USE_SPI1_INTERRUPT
#define USE_SPI2_INTERRUPT
#define USE_SPI3_INTERRUPT

/// EXTI interrupts

#define USE_EXTI0_INTERRUPT
#define USE_EXTI1_INTERRUPT
#define USE_EXTI2_INTERRUPT
#define USE_EXTI3_INTERRUPT
#define USE_EXTI4_INTERRUPT
#define USE_EXTI9_5_INTERRUPT
#define USE_EXTI15_10_INTERRUPT

/// SDIO interrupt

#define USE_SDIO_INTERRUPT

/// Timer interrupts

#define USE_TIMER2_INTERRUPT
#define USE_TIMER3_INTERRUPT
#define USE_TIMER4_INTERRUPT
#define USE_TIMER5_INTERRUPT
#define USE_TIMER6_INTERRUPT
#define USE_TIMER7_INTERRUPT
