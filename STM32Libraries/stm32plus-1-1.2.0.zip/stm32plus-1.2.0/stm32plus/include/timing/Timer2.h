/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#pragma once

#include "timing/Timer.h"


namespace stm32plus {

	/**
	 * @brief Implementation of Timer for TIM2
	 */

	class Timer2 : public Timer {

		public:
			Timer2();

			// overrides from Timer

			void enableGpioOutput(uint16_t channel,bool enable) const;

			virtual uint16_t getTimerIndex() const {
				return 1;
			}
	};
}
