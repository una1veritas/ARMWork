/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#pragma once

#include "fx/easing/EasingBase.h"

namespace stm32plus {
	namespace fx {

		/**
		 * @brief Linear ease. Really a dummy as it doesn't ease at all.
		 */

		class LinearEase : public EasingBase {

			public:
				/// no acceleration
				virtual double easeIn(double time_) const;

				/// no acceleration
				virtual double easeOut(double time_) const;

				/// no acceleration
				virtual double easeInOut(double time_) const;
		};
	}
}
