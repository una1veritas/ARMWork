/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include "stdafx.h"
#include "LcdManager.h"
#include "display/graphic/tft/ili9325/ILI9325Gamma.h"

#include "display/graphic/ColourNames.h"
#include "display/graphic/Font_apple_8.h"
#include "gpio/GpioPort.h"


/*
 * Initialiser, create the LCD object. Gamma and fsmc objects need to be in scope but
 * can be lost on the heap as they'll never be referenced again externally.
 */

bool LcdManager::initialise() {

	// set up the FSMC on bank 0 with A16 as the RS line

	GpioPort pd(GPIOD),pe(GPIOE);

	// reset on port E pin 1

	pe[1].initialise(GPIO_Speed_50MHz,GPIO_Mode_Out_PP);

	Fsmc8080LcdTiming fsmcTiming(2,5);
	_accessMode=new Fsmc16BitAccessMode(FSMC_Bank1_NORSRAM1,fsmcTiming,16,pd[11],pe[1]);

	// create the LCD and object

	_lcd=new LcdAccess(*_accessMode);

	// create and select the font

	_font=new Font_APPLE8();
	*_lcd << *_font;

	// create the terminal object using the selected font

	_terminal=new TerminalAccess(_lcd);

	// apply gamma settings

	ILI9325Gamma gamma(0x0006,0x0101,0x0003,0x0106,0x0b02,0x0302,0x0707,0x0007,0x0600,0x020b);
	_lcd->applyGamma(gamma);

	// clear down to black

	_lcd->setBackground(ColourNames::BLACK);
	_lcd->setForeground(ColourNames::WHITE);

	_terminal->clearScreen();

	// lights on at 100% in 4ms steps from zero.

	_backlight=new DefaultBacklight;
	_backlight->fadeTo(100,4);

	return true;
}
