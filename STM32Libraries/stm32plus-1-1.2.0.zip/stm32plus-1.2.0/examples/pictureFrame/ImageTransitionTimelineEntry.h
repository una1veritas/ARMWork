/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011,2012 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#pragma once

#include "fx/TimelineEntry.h"
#include "fx/easing/BounceEase.h"
#include "device/BlockDevice.h"
#include "LcdManager.h"


using namespace stm32plus;
using namespace stm32plus::display;
using namespace stm32plus::fx;


/*
 * Class to manage the transition between images. Uses an easing function
 * and the native scrolling ability of the LCD.
 */

class ImageTransitionTimelineEntry : public TimelineEntry {

	protected:
		LcdManager::LcdAccess& _lcd;
		BlockDevice& _blockDevice;
		uint32_t _blockIndex;
		uint32_t _lastBlockIndex;
		int16_t _currentScrollPosition;
		BounceEase _ease;

	public:
		ImageTransitionTimelineEntry(LcdManager::LcdAccess& lcd,BlockDevice& bd,uint32_t transitionTime);

		void setNewImageBlockIndex(uint32_t blockIndex) {
			_lastBlockIndex=_blockIndex;
			_blockIndex=blockIndex;
		}

		// overrides from Observer
		virtual void onNotify(Observable& sender,ObservableEvent::E event,void *context);
};
