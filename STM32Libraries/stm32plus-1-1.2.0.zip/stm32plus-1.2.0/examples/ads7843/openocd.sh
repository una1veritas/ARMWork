#!/bin/sh

if [ "$#" != 1 ]; then
    echo "Usage: $0 <filename.bin>"
    exit 1;
fi

openocd -f openocd.cfg -c "init;loadImage $1"
