//
// glcd build information
// This headerfile is automatically generated
//

#ifndef __glcd_Buildinfo_h__
#define __glcd_Buildinfo_h__

#define GLCD_GLCDLIB_DATESTR	"Mon Dec  5 01:50:07 CST 2011"
#define GLCD_GLCDLIB_BUILDSTR	"442"
#endif
